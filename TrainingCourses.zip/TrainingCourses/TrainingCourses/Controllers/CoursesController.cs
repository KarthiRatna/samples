﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace TrainingCourses.Controllers
{
    public class CoursesController : ApiController
    {
        static List<course> CourseList = initCourse();

        private static List<course> initCourse()
        {
            List<course> ret = new List<course>();
            ret.Add(new course { id = 0, title = "WEB API" });
            ret.Add(new course { id = 1, title = "ASP.NET" });
            ret.Add(new course { id = 2, title = "ASP.NET MVC" });
            ret.Add(new course { id = 3, title = "AWS" });
            return ret;
        }

        public IEnumerable<course> Get()
        {
            return CourseList;
        }
        public HttpResponseMessage Get(int num)
        {
            course s = (from x in CourseList
                       where x.id == num
                       select x).FirstOrDefault();
            if (s != null)
            {
               return Request.CreateResponse<course>(HttpStatusCode.OK, s);
            }
            else
            {
               return Request.CreateErrorResponse(HttpStatusCode.NotFound, "There is no courses for this ID");
            }
        }
        public HttpResponseMessage post([FromBody]course addcourse)
        {
            addcourse.id = CourseList.Count;
            CourseList.Add(addcourse);
            var msg = Request.CreateResponse(HttpStatusCode.Created);
            msg.Headers.Location = new Uri(Request.RequestUri + CourseList.Count.ToString());
            return msg;
        }
        public class course
        {
            public int id;
            public string title;
        }
    }
}
